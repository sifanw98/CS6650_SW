# AlbumsProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**year** | **String** |  |  [optional]
