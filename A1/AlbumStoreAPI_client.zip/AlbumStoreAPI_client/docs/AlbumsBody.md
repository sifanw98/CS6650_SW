# AlbumsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | [**File**](File.md) |  |  [optional]
**profile** | [**AlbumsProfile**](AlbumsProfile.md) |  |  [optional]
